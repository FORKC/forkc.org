<?php return array (
  'title' => 'Core Values: Standard',
  'elements' =>
  array (
    0 =>
    array (
      'elType' => 'section',
      'title' => 'Our Core Values',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Our Core Values',
                  'level' => 'h2',
                  'looks_like' => 'h1',
                  'accent' => false,
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                ),
              ),
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'bg_color' => '',
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
        1 =>
        array (
          'elType' => 'row',
          'title' => 'Row 2',
          'columnLayout' => '1/2 + 1/2',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'icon',
                  'type' => 'mortar-board',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'display: block; font-size: 3em; line-height: 1;',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'We Foster Education',
                  'level' => 'h3',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 0.75em 0; font-size: 1.35em; letter-spacing: 0.1em; text-transform: uppercase;',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '45px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'icon',
                  'type' => 'trophy',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'display: block; font-size: 3em; line-height: 1;',
                ),
                1 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'We Pursue Excellence',
                  'level' => 'h3',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 0.75em 0; font-size: 1.35em; letter-spacing: 0.1em; text-transform: uppercase;',
                  'title' => 'Copy of undefined',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'bg_color' => '',
          'margin' =>
          array (
            0 => '45px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
        2 =>
        array (
          'elType' => 'row',
          'title' => 'Row 3',
          'columnLayout' => '1/2 + 1/2',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'icon',
                  'type' => 'lightbulb-o',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'display: block; font-size: 3em; line-height: 1;',
                  'title' => 'Copy of Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'We Practice Honesty',
                  'level' => 'h3',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 0.75em 0; font-size: 1.35em; letter-spacing: 0.1em; text-transform: uppercase;',
                  'title' => 'Copy of undefined',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of Copy of undefined',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '45px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'icon',
                  'type' => 'paint-brush',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'display: block; font-size: 3em; line-height: 1;',
                  'title' => 'Copy of undefined',
                ),
                1 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'We Create Fun',
                  'level' => 'h3',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => 'margin: 0.75em 0; font-size: 1.35em; letter-spacing: 0.1em; text-transform: uppercase;',
                  'title' => 'Copy of Copy of undefined',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pretium, nisi ut volutpat mollis, leo risus interdum arcu, eget facilisis quam felis id mauris. Ut convallis, lacus nec ornare volutpat, velit turpis scelerisque purus, quis mollis velit purus ac massa. Fusce quis urna metus. Donec et lacus et sem lacinia cursus.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'bg_color' => '',
          'margin' =>
          array (
            0 => '45px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '10%',
        1 => '0px',
        2 => '10%',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' =>
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'linked',
      ),
      'text_align' => '',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
  ),
);